-- ============================================================
--  AI Adaptive  v1.1.0
--  A CSP Lua App for Assetto Corsa
--
--  Author  : Simo1206
--  License : MIT
--  Requires: Custom Shaders Patch >= 0.1.79
--
--  What it does:
--    - Observes each AI car for 2 laps, builds a speed profile
--    - Calibrates aiLevel per car automatically (no config files)
--    - Varies aiLevel each update to avoid robotic stints
--    - Applies personality (aggression/caution) driven by consistency
--    - Detects contacts via car.collisionDepth (no false positives
--      from hard braking) and penalises involved cars
--    - Proximity reduction: reduces level in close wheel-to-wheel fights
--    - Yellow zone: reduces level near stationary cars on track
--    - Launch boost: high level + aggression for the first 30s
--
--  Installation:
--    Copy the "ai_adaptive" folder to:
--      assettocorsa/apps/lua/
--    Enable the app from the in-game app bar.
-- ============================================================

math.randomseed(os.time())

local CFG      = require("src/config")
local utils    = require("src/utils")
local observer = require("src/controllers/observer")
local calib    = require("src/controllers/calibrator")
local dynamics = require("src/controllers/dynamics")
local window   = require("src/ui/window")

-- ---- Sim state ----
local sim          = ac.getSim()
local N            = sim.carsCount
local carData      = {}
local obsDone      = false
local updateTimer  = 0.0
local sessionTimer = 0.0
local launchDone   = false

local uiState = {
    statusMsg   = "Observation: 0 / " .. CFG.OBSERVATION_LAPS .. " laps...",
    statusColor = rgbm(1, 0.8, 0, 1),
    obsDone     = false,
    launchDone  = false,
    sessionTimer = 0.0,
    totalCars   = N,
}

-- Inizializza struttura dati per ogni AI
for i = 1, N - 1 do
    carData[i] = observer.createCarData(i)
end

-- Applica launch boost subito, prima che AC usi i suoi default conservativi
for i = 1, N - 1 do
    physics.setAILevel(i, CFG.LAUNCH_LEVEL)
    physics.setAIAggression(i, CFG.LAUNCH_AGGRESSION)
    physics.setAICaution(i, CFG.LAUNCH_CAUTION)
    carData[i].currentLevel = CFG.LAUNCH_LEVEL
    carData[i].aggression   = CFG.LAUNCH_AGGRESSION
    carData[i].caution      = CFG.LAUNCH_CAUTION
end

utils.log(string.format("v1.1.0 avviato — vetture: %d (AI: %d)", N, N - 1))
utils.log("Launch boost applicato.")


-- ============================================================
--  MAIN LOOP
-- ============================================================
function script.update(dt)
    sim            = ac.getSim()
    sessionTimer   = sessionTimer + dt
    uiState.sessionTimer = sessionTimer

    -- Global caution runs every frame, including during the two-lap observation
    -- phase. The player should never be able to bypass it by being in calibration.
    dynamics.updateCaution(dt, N)

    -- Fine finestra launch boost
    if not launchDone and sessionTimer >= CFG.LAUNCH_WINDOW then
        launchDone       = true
        uiState.launchDone = true
        utils.log("Launch window terminata.")
        -- Se la calibrazione è già pronta, applica subito i livelli calibrati
        if obsDone then
            for i = 1, N - 1 do
                physics.setAILevel(i, carData[i].baseLevel)
                carData[i].currentLevel = carData[i].baseLevel
            end
        end
    end

    -- ---- FASE 1: OSSERVAZIONE ----
    if not obsDone then
        for i = 1, N - 1 do
            observer.observe(carData[i], i, dt)
        end

        local median = observer.medianLapsCompleted(carData, N)
        local active = 0
        for i = 1, N - 1 do
            local car = ac.getCar(i)
            if car and car.lapCount > 0 then active = active + 1 end
        end

        uiState.statusMsg = string.format(
            "Osservazione: %d / %d giri  (%d/%d vetture attive)...",
            median, CFG.OBSERVATION_LAPS, active, N - 1)

        if median >= CFG.OBSERVATION_LAPS then
            if calib.calibrate(carData, N) then
                obsDone            = true
                uiState.obsDone    = true
                uiState.statusMsg  = string.format("Attivo — %d vetture calibrate.", N - 1)
                uiState.statusColor = rgbm(0.2, 1, 0.4, 1)
                utils.log("Calibrazione completata.")
            else
                uiState.statusMsg  = "Calibrazione fallita: dati insufficienti."
                uiState.statusColor = rgbm(1, 0.3, 0.3, 1)
            end
        end
        return
    end

    -- ---- FASE 2: DINAMICA ----
    -- Contact detection ogni frame (precisione massima)
    for i = 1, N - 1 do
        local car = ac.getCar(i)
        if car then
            -- Riusa la funzione di osservazione per contact + recovery
            observer.observe(carData[i], i, dt)
        end
    end

    -- Aggiornamento livelli a intervallo fisso
    updateTimer = updateTimer + dt
    if updateTimer < CFG.UPDATE_INTERVAL then return end
    updateTimer = 0.0

    dynamics.updateAll(carData, N, dt)
end


-- ============================================================
--  UI
-- ============================================================
function script.windowMain()
    window.draw(uiState, carData, CFG)
end
