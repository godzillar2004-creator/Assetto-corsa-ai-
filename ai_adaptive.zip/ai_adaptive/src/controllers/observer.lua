-- ============================================================
--  src/controllers/observer.lua  —  AI Adaptive v1.1.0
--  Fase 1: osserva le vetture AI per N giri e raccoglie
--  statistiche di velocità e collisioni.
-- ============================================================

local CFG   = require("src/config")
local utils = require("src/utils")

local M = {}

-- Inizializza la struttura dati per una vettura AI.
function M.createCarData(carIndex)
    local car = ac.getCar(carIndex)
    return {
        baseLevel        = CFG.BASE_AI_LEVEL,
        currentLevel     = CFG.BASE_AI_LEVEL,
        aggression       = CFG.BASE_AGGRESSION,
        caution          = CFG.BASE_CAUTION,

        -- Osservazione velocità
        lapSpeedsMax     = {},          -- vMax registrata per ogni giro osservato
        lapCount         = 0,           -- giri completati dall'avvio app
        prevAcLaps       = car and car.lapCount or 0,
        sessionMaxSpeed  = 0.0,         -- vMax nel giro corrente

        -- Contact detection (tramite collisionDepth, non delta-v)
        collisionCount   = 0,
        inCollision      = false,       -- true mentre collisionDepth > soglia
        consistencyScore = 1.0,
        consistTimer     = 0.0,         -- tempo dall'ultimo contatto (recovery)
        postContactTimer = 0.0,       -- temporary safety window after contact
    }
end

-- Rileva e processa un contatto usando car.collisionDepth.
-- Più preciso del metodo a delta velocità: nessun falso positivo in frenata.
-- Il flag inCollision garantisce che ogni contatto sia contato una sola volta.
local function updateContacts(d, car, carIndex)
    local depth = car.collisionDepth or 0.0
    if depth > CFG.COLL_DEPTH_MIN then
        if not d.inCollision then
            d.inCollision    = true
            d.collisionCount = d.collisionCount + 1
            d.consistTimer   = 0.0
            d.postContactTimer = CFG.POST_CONTACT_SAFETY

            -- Penalità diversa per contatti frontali/posteriori vs laterali leggeri
            local penalty = 0.10
            if car.collisionPosition then
                local z = car.collisionPosition.z or 0
                if math.abs(z) > 0.3 then penalty = 0.20 end
            end
            d.consistencyScore = utils.clamp(d.consistencyScore - penalty,
                                             CFG.CONSISTENCY_MIN, 1.0)
            utils.log(string.format(
                "Car %d: contatto #%d  depth=%.2f  consistency=%.2f",
                carIndex, d.collisionCount, depth, d.consistencyScore))
        end
    else
        d.inCollision = false
    end
end

-- Recovery graduale della consistency dopo un incidente.
local function recoverConsistency(d, dt)
    if d.postContactTimer > 0 then
        d.postContactTimer = math.max(0, d.postContactTimer - dt)
    end
    if d.consistencyScore < 1.0 then
        d.consistTimer = d.consistTimer + dt
        if d.consistTimer >= CFG.COLL_RECOVER then
            d.consistTimer = 0.0
            d.consistencyScore = utils.clamp(d.consistencyScore + 0.05,
                                             CFG.CONSISTENCY_MIN, 1.0)
        end
    end
end

-- Aggiorna i dati di osservazione per una singola vettura AI (chiamato ogni frame).
function M.observe(carData, carIndex, dt)
    local car = ac.getCar(carIndex)
    if not car then return end

    local speed = car.speedKmh
    if speed > carData.sessionMaxSpeed then
        carData.sessionMaxSpeed = speed
    end

    -- Rilevamento giro completato con car.lapCount nativo.
    -- Usa delta rispetto al frame precedente: immune a reset di sessione.
    local acLaps = car.lapCount
    if acLaps > carData.prevAcLaps then
        carData.lapCount = carData.lapCount + (acLaps - carData.prevAcLaps)
        table.insert(carData.lapSpeedsMax, carData.sessionMaxSpeed)
        carData.sessionMaxSpeed = 0.0
        utils.log(string.format("Car %d: giro %d (vMax=%.0f km/h)",
            carIndex, carData.lapCount, carData.lapSpeedsMax[#carData.lapSpeedsMax]))
    end
    carData.prevAcLaps = acLaps

    -- Contact detection e recovery
    updateContacts(carData, car, carIndex)
    recoverConsistency(carData, dt)
end

-- Ritorna la MEDIANA dei giri completati tra le vetture AI attive.
-- La mediana è immune a vetture ritirate o ai box che bloccano la calibrazione.
function M.medianLapsCompleted(allCarData, totalCars)
    local counts = {}
    for i = 1, totalCars - 1 do
        local d   = allCarData[i]
        local car = ac.getCar(i)
        -- Includi solo vetture che hanno percorso almeno un giro
        if d and car and car.lapCount > 0 then
            table.insert(counts, d.lapCount)
        end
    end
    if #counts == 0 then return 0 end
    table.sort(counts)
    return counts[math.ceil(#counts / 2)]
end

-- Espone recoverConsistency per uso in fase dinamica (post-calibrazione)
M.recoverConsistency = recoverConsistency

return M
