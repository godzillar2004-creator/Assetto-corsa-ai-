-- ============================================================
--  src/controllers/calibrator.lua  —  AI Adaptive v1.1.0
--  Fase 2: calcola il baseLevel per ogni AI in base al
--  profilo di velocità relativo osservato.
-- ============================================================

local CFG   = require("src/config")
local utils = require("src/utils")

local M = {}

function M.calibrate(allCarData, totalCars)
    local globalMax = 0
    for i = 1, totalCars - 1 do
        local d = allCarData[i]
        if d and #d.lapSpeedsMax > 0 then
            local avg = utils.average(d.lapSpeedsMax)
            if avg > globalMax then globalMax = avg end
        end
    end

    if globalMax == 0 then
        utils.log("ERRORE calibrazione: nessun dato di velocità.")
        return false
    end

    utils.log(string.format("Calibrazione: velocità riferimento = %.0f km/h", globalMax))

    for i = 1, totalCars - 1 do
        local d = allCarData[i]
        if d and #d.lapSpeedsMax > 0 then
            local ratio        = utils.average(d.lapSpeedsMax) / globalMax
            local compensation = (1.0 - ratio) * 0.5
            local level        = utils.clamp(CFG.BASE_AI_LEVEL + compensation, 0.70, 1.0)

            d.baseLevel    = level
            d.currentLevel = level
            physics.setAILevel(i, level)

            utils.log(string.format(
                "Car %d: ratio=%.2f  comp=+%.3f  level=%.3f",
                i, ratio, compensation, level))
        end
    end

    return true
end

return M
