-- ============================================================
--  src/controllers/dynamics.lua  —  AI Adaptive v1.1.0
--  Fase 3: aggiornamento dinamico livelli, personalità,
--  anti-sportellate, zone gialle.
-- ============================================================

local CFG   = require("src/config")
local utils = require("src/utils")

local M = {}

local globalCautionTimer = 0.0
local globalCrashTimer = 0.0

local function detectGlobalCaution(totalCars)
    local crash = false
    local yellow = false
    for j = 0, totalCars - 1 do
        local o = ac.getCar(j)
        if o and o.isConnected then
            if (o.collisionDepth or 0) > CFG.COLL_DEPTH_MIN then
                crash = true
            end
            if not o.isInPitlane and o.speedKmh < CFG.STOPPED_CAR_THRESHOLD and o.lapCount > 0 then
                -- Only treat a stopped car as a yellow when it is not parked
                -- in the pits. This is intentionally global: everyone reacts.
                yellow = true
            end
        end
    end
    if crash then globalCrashTimer = CFG.GLOBAL_CRASH_TIME end
    if yellow then globalCautionTimer = CFG.GLOBAL_CAUTION_TIME end
end

local function updateGlobalCaution(dt, totalCars)
    detectGlobalCaution(totalCars)
    globalCrashTimer = math.max(0, globalCrashTimer - dt)
    globalCautionTimer = math.max(0, globalCautionTimer - dt)
end

local function globalCautionActive()
    return globalCautionTimer > 0 or globalCrashTimer > 0
end

local function slowPlayerForCaution()
    if not globalCautionActive() then return end
    local player = ac.getCar(0)
    if not player or player.isInPitlane then return end

    -- Force a real caution-speed response rather than merely reducing throttle.
    -- Target is 30 mph (48.28 km/h). Above that speed throttle is cut and
    -- progressive braking is applied. Once near 30 mph, a small throttle cap
    -- lets the car hold roughly caution speed without needing game penalties.
    local speed = player.speedKmh or 0
    local target = CFG.PLAYER_CAUTION_TARGET_KMH

    if speed > target + 1.0 then
        local excess = speed - target
        local brake = CFG.PLAYER_CAUTION_BRAKE + excess / 120.0
        brake = math.min(brake, CFG.PLAYER_CAUTION_BRAKE_MAX)
        ac.setGas(0.0)
        ac.setBrake(math.max(player.brake or 0, brake))
    else
        ac.setGas(math.min(player.gas or 0, CFG.PLAYER_CAUTION_GAS))
        -- Preserve any brake the player is already applying.
        ac.setBrake(player.brake or 0)
    end
end

-- Called every frame so player caution is not delayed by the 2-second AI update
-- interval or by the initial observation/calibration phase.
function M.updateCaution(dt, totalCars)
    updateGlobalCaution(dt or 0, totalCars)
    slowPlayerForCaution()
end

local function isYellowZone(carIndex, totalCars)
    local me = ac.getCar(carIndex)
    if not me then return false end
    for j = 0, totalCars - 1 do
        if j ~= carIndex then
            local o = ac.getCar(j)
            if o and o.isConnected then
                local dist = utils.splineDist(me.splinePosition, o.splinePosition)
                if dist < CFG.YELLOW_ZONE and o.speedKmh < CFG.YELLOW_SPEED_THRESHOLD then
                    return true
                end
            end
        end
    end
    return false
end

local function isProximityRisk(carIndex, totalCars)
    local me = ac.getCar(carIndex)
    if not me then return false end
    for j = 0, totalCars - 1 do
        if j ~= carIndex then
            local o = ac.getCar(j)
            if o and o.isConnected then
                if utils.splineDist(me.splinePosition, o.splinePosition) < CFG.PROXIMITY_MARGIN then
                    return true
                end
            end
        end
    end
    return false
end

-- Aggiorna aggression e caution in base alla consistency del pilota.
-- Pilota nervoso dopo un contatto: più aggressivo, meno cauto.
local function applyPersonality(d, carIndex)
    -- After contact, become MORE cautious and slightly LESS aggressive.
    -- This avoids the original mod's feedback loop where a crash could
    -- make the driver increasingly aggressive and unstable.
    local aggr = utils.clamp(
        CFG.BASE_AGGRESSION - (1.0 - d.consistencyScore) * 0.20 + utils.randVar(0.025),
        0.15, 0.75)
    local caut = utils.clamp(
        CFG.BASE_CAUTION + (1.0 - d.consistencyScore) * 0.25 + utils.randVar(0.025),
        0.30, 0.95)

    -- Extra caution for a short period immediately after a collision.
    if d.postContactTimer and d.postContactTimer > 0 then
        aggr = math.min(aggr, 0.32)
        caut = math.max(caut, 0.78)
    end

    if math.abs(aggr - d.aggression) > 0.02 then
        physics.setAIAggression(carIndex, aggr)
        d.aggression = aggr
    end
    if math.abs(caut - d.caution) > 0.02 then
        physics.setAICaution(carIndex, caut)
        d.caution = caut
    end
end

-- Aggiorna livello e personalità per una singola vettura.
function M.update(carData, carIndex, totalCars)
    local d = carData[carIndex]
    if not d then return end

    local level = d.baseLevel

    if globalCautionActive() then
        level = level - CFG.GLOBAL_LEVEL_PENALTY
    end

    -- Variazione casuale: AI poco consistente varia di più
    local varRange = CFG.LAP_VARIATION / d.consistencyScore
    level = level + utils.randVar(varRange)

    if isProximityRisk(carIndex, totalCars) then
        level = level - CFG.PROXIMITY_REDUCTION
    end

    if d.postContactTimer and d.postContactTimer > 0 then
        level = level - CFG.POST_CONTACT_LEVEL_DROP
    end

    if isYellowZone(carIndex, totalCars) then
        level = level - CFG.YELLOW_PENALTY
    end

    level = utils.clamp(level, 0.60, 1.0)

    if math.abs(level - d.currentLevel) > 0.005 then
        physics.setAILevel(carIndex, level)
        d.currentLevel = level
    end

    -- Personalità: era assente nella versione modulare precedente
    applyPersonality(d, carIndex)
end

function M.updateAll(carData, totalCars, dt)
    for i = 1, totalCars - 1 do
        M.update(carData, i, totalCars)
    end
end

return M
