-- ============================================================
--  src/config.lua  —  AI Adaptive v1.1.0
--  Tutti i parametri configurabili in un unico posto.
-- ============================================================

return {
    -- Giri di osservazione prima di calibrare i livelli AI.
    -- Aumenta per una calibrazione più precisa (ma aspetti di più).
    OBSERVATION_LAPS        = 2,

    -- Livello AI base (0.0 = lentissimo, 1.0 = massimo).
    BASE_AI_LEVEL           = 0.92,

    -- Personalità base.
    BASE_AGGRESSION         = 0.47,   -- 0=passivo, 1=aggressivo
    BASE_CAUTION            = 0.57,   -- 0=nessuna, 1=massima

    -- Variazione casuale per ogni aggiornamento (±%).
    -- 0.04 = ±4%: impercettibile ma efficace per stint non robotici.
    LAP_VARIATION           = 0.025,

    -- Intervallo in secondi tra ogni aggiornamento dinamico dei livelli.
    -- Non scendere sotto 0.5 per non stressare il motore fisico.
    UPDATE_INTERVAL         = 2.0,

    -- ---- Contact detection ----
    -- Usa car.collisionDepth (nativo CSP). Metodo preciso, nessun falso
    -- positivo in frenata. Sostituisce il vecchio approccio a delta velocità.
    COLL_DEPTH_MIN          = 0.05,   -- soglia minima di profondità contatto

    -- Penalità al consistency score per ogni contatto.
    --   Frontale/posteriore (|collisionPosition.z| > 0.3): 0.20
    --   Laterale leggero:                                  0.10
    -- (calcolata dinamicamente in observer.lua)

    -- Secondi necessari per recuperare +0.05 di consistency dopo un contatto.
    COLL_RECOVER            = 30.0

    -- Temporary safety window after contact.
    POST_CONTACT_SAFETY     = 12.0,
    POST_CONTACT_LEVEL_DROP = 0.025,

    -- Consistency score minimo (pilota molto inconsistente).
    CONSISTENCY_MIN         = 0.20,

    -- ---- Proximity (anti-sportellate) ----
    -- Distanza spline entro cui due vetture sono considerate "troppo vicine".
    -- 0.015 ≈ 1.5% del giro, circa 20-30 m su un tracciato da 2 km.
    PROXIMITY_MARGIN        = 0.015,

    -- Riduzione livello quando due vetture sono troppo vicine.
    PROXIMITY_REDUCTION     = 0.035,

    -- ---- Yellow flag (vettura ferma vicina) ----
    YELLOW_SPEED_THRESHOLD  = 15,     -- km/h sotto cui una vettura è "ferma"
    YELLOW_ZONE             = 0.04,   -- raggio spline zona gialla
    YELLOW_PENALTY          = 0.18,   -- riduzione livello in zona gialla

    -- ---- Global caution / yellow event ----
    -- A caution is triggered by a collision anywhere or a stopped car
    -- outside the pits. It affects AI and the player.
    GLOBAL_CAUTION_TIME    = 10.0,
    GLOBAL_CRASH_TIME      = 12.0,
    GLOBAL_LEVEL_PENALTY   = 0.14,
    PLAYER_CAUTION_BRAKE   = 0.18,
    PLAYER_CAUTION_GAS     = 0.18,
    PLAYER_CAUTION_TARGET_KMH = 48.28,  -- 30 mph
    PLAYER_CAUTION_BRAKE_MAX  = 0.35,
    STOPPED_CAR_THRESHOLD  = 15,

    -- ---- Launch boost (standing start) ----
    LAUNCH_WINDOW           = 30.0,   -- secondi di boost all'avvio sessione
    LAUNCH_LEVEL            = 0.94,
    LAUNCH_AGGRESSION       = 0.68,
    LAUNCH_CAUTION          = 0.58,
}
