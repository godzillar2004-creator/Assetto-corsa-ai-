-- ============================================================
--  src/utils.lua  —  AI Adaptive v1.1.0
--  Funzioni di utilità condivise da tutti i moduli.
-- ============================================================

local M = {}

-- Clamp un valore tra lo e hi
function M.clamp(v, lo, hi)
    return math.max(lo, math.min(hi, v))
end

-- Media di una tabella numerica
function M.average(t)
    if #t == 0 then return 0 end
    local s = 0
    for _, v in ipairs(t) do s = s + v end
    return s / #t
end

-- Distanza ciclica su splinePosition (0..1)
function M.splineDist(a, b)
    local d = math.abs(a - b)
    return d > 0.5 and (1.0 - d) or d
end

-- Log con prefisso standard
function M.log(msg)
    ac.log("[AI Adaptive] " .. tostring(msg))
end

-- Variazione casuale simmetrica: valore in [-range, +range]
function M.randVar(range)
    return (math.random() * 2.0 - 1.0) * range
end

return M
