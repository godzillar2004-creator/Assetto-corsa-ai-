-- ============================================================
--  src/ui/window.lua  —  AI Adaptive v1.1.0
--  Finestra principale dell'app.
-- ============================================================

local M = {}

local COLOR_OK      = rgbm(0.2, 1.0, 0.4, 1)
local COLOR_WARN    = rgbm(1.0, 0.8, 0.0, 1)
local COLOR_ERR     = rgbm(1.0, 0.3, 0.3, 1)
local COLOR_DIM     = rgbm(0.5, 0.5, 0.5, 1)
local COLOR_HEADER  = rgbm(0.6, 0.8, 1.0, 1)
local COLOR_CAR_OK  = rgbm(0.9, 0.9, 0.9, 1)
local COLOR_CAR_COL = rgbm(1.0, 0.6, 0.2, 1)
local COLOR_CAR_BAD = rgbm(1.0, 0.3, 0.2, 1)
local COLOR_LAUNCH  = rgbm(1.0, 0.6, 0.0, 1)

-- state: { statusMsg, statusColor, obsDone, launchDone, sessionTimer,
--          totalCars }
-- carData: tabella indicizzata 1..N-1
-- cfg: modulo config
function M.draw(state, carData, cfg)
    ui.pushFont(ui.Font.Title)
    ui.text("AI Adaptive  v1.1.0")
    ui.popFont()
    ui.separator()

    ui.textColored(state.statusMsg, state.statusColor)

    -- Countdown launch boost
    if not state.launchDone then
        local remaining = math.max(0, cfg.LAUNCH_WINDOW - state.sessionTimer)
        ui.textColored(
            string.format("Launch boost attivo — %.0fs rimanenti", remaining),
            COLOR_LAUNCH)
    end

    ui.separator()

    -- ---- Fase osservazione ----
    if not state.obsDone then
        ui.text(string.format(
            "Completa %d giri per attivare la calibrazione automatica.",
            cfg.OBSERVATION_LAPS))
        ui.newLine()
        ui.pushFont(ui.Font.Monospace)
        ui.textColored(string.format("%-4s %-8s %-6s", "#", "AC laps", "Ours"), COLOR_HEADER)
        ui.separator()
        for i = 1, state.totalCars - 1 do
            local d   = carData[i]
            local car = ac.getCar(i)
            ui.text(string.format("%-4d %-8d %-6d",
                i,
                car and car.lapCount or -1,
                d and d.lapCount or 0))
        end
        ui.popFont()
        ui.separator()
        ui.pushFont(ui.Font.Small)
        ui.textColored("L'app lavora in background anche con questa finestra chiusa.", COLOR_DIM)
        ui.popFont()
        return
    end

    -- ---- Fase attiva: tabella completa ----
    ui.pushFont(ui.Font.Monospace)
    ui.textColored(
        string.format("%-3s %-6s %-6s %-5s %-5s %-5s", "#", "Base", "Live", "Aggr", "Caut", "Cons"),
        COLOR_HEADER)
    ui.separator()

    for i = 1, state.totalCars - 1 do
        local d = carData[i]
        if d then
            local col = d.collisionCount > 3 and COLOR_CAR_BAD
                     or d.collisionCount > 0 and COLOR_CAR_COL
                     or COLOR_CAR_OK

            ui.textColored(
                string.format("%s%-3d %-6s %-6s %-5s %-5s %-5s",
                    d.inCollision and "!" or " ",
                    i,
                    string.format("%.3f", d.baseLevel),
                    string.format("%.3f", d.currentLevel),
                    string.format("%.2f", d.aggression),
                    string.format("%.2f", d.caution),
                    string.format("%.2f", d.consistencyScore)),
                col)
        end
    end
    ui.popFont()

    ui.separator()
    ui.pushFont(ui.Font.Small)
    ui.textColored("! = contatto attivo  |  Arancio = contatti  |  Rosso = molti contatti", COLOR_DIM)
    ui.textColored("Cons. cala sui contatti, +0.05 ogni 30s di guida pulita", COLOR_DIM)
    ui.popFont()
end

return M
