# AI Adaptive — v1.3 Global Caution / 30 MPH Player Limit
**A CSP Lua App for Assetto Corsa**

> Automatically calibrates AI difficulty per car, varies behaviour each stint to avoid robotic pacing, and penalises drivers involved in contacts — all with zero config files required.

---

## Features

| Feature | Description |
|---|---|
| **Auto-calibration** | Observes every AI car for 2 laps and sets an individual `aiLevel` based on each car's relative top speed. Works transparently in mixed-class grids. |
| **Stint variation** | Level fluctuates slightly each update cycle (±4%) so AI behaviour never feels robotic. |
| **Contact detection** | Uses CSP's native `car.collisionDepth` — no false positives from hard braking. Each contact lowers a driver's *consistency score*, increasing pace variability. |
| **Personality system** | Aggression and caution adjust dynamically based on consistency: a driver who just had a collision becomes more erratic for the next ~90 seconds. |
| **Proximity reduction** | AI level is temporarily reduced in close wheel-to-wheel battles to limit bumping. |
| **Yellow zone** | Level is reduced near stationary cars on track (implicit yellow flag). |
| **Launch boost** | High level + high aggression for the first 30s to avoid slow standing starts. |

---

## Requirements

- Assetto Corsa (Steam)
- [Custom Shaders Patch](https://acstuff.ru/patch/) **>= 0.1.79**

---

## Installation

1. Download and extract the zip.
2. Copy the `ai_adaptive` folder into:
   ```
   assettocorsa/apps/lua/
   ```
   The folder structure must be:
   ```
   apps/lua/ai_adaptive/
       ai_adaptive.lua
       manifest.ini
       icon.png
       src/
           config.lua
           utils.lua
           controllers/
               observer.lua
               calibrator.lua
               dynamics.lua
           ui/
               window.lua
   ```
3. Launch Assetto Corsa, start any session with AI cars.
4. Enable **AI Adaptive** from the in-game app bar (right side).

---

## How it works

### Phase 1 — Observation (first 2 laps)
The app watches every AI car and records peak speed each lap. A **median lap count** is used to trigger calibration, so one retired or pitted car cannot block the process indefinitely.

### Phase 2 — Calibration
The fastest car on track becomes the reference (ratio = 1.0). Slower cars receive a proportional level boost so they remain competitive regardless of car category.

Example: if the reference car averages 220 km/h and another averages 187 km/h (ratio ≈ 0.85), the slower car gets `+0.075` added to its level.

### Phase 3 — Dynamic updates (every 2s)
Each update cycle:
1. Random variation (±4%, wider if consistency is low)
2. Proximity penalty if a rival is within ~20-30m on the spline
3. Yellow zone penalty if there's a stationary car nearby
4. Level is clamped to [0.60, 1.0]
5. Aggression and caution are updated to reflect the driver's current consistency

### Contact detection
Uses `car.collisionDepth` (native CSP property), not velocity deltas — **no false positives from heavy braking**. Each distinct contact increments a counter and reduces the driver's consistency score:
- Frontal/rear impact (`|collisionPosition.z| > 0.3`): −0.20
- Light side contact: −0.10
- Recovery: +0.05 every 30 seconds of clean driving

---

## Configuration

All parameters are in `src/config.lua`. The most useful ones:

| Parameter | Default | Description |
|---|---|---|
| `OBSERVATION_LAPS` | `2` | Laps to observe before calibrating. Increase for more accuracy. |
| `BASE_AI_LEVEL` | `0.92` | Baseline level for the fastest car. |
| `LAP_VARIATION` | `0.04` | Max random shift per update (±4%). |
| `UPDATE_INTERVAL` | `2.0` | Seconds between dynamic updates. |
| `COLL_DEPTH_MIN` | `0.05` | `collisionDepth` threshold to register a contact. |
| `COLL_RECOVER` | `30.0` | Seconds to recover +0.05 consistency. |
| `LAUNCH_WINDOW` | `30.0` | Duration of launch boost at session start. |

---

## Compatibility

- Works with any track and any car combination.
- The app is invisible online (`FLAGS = HIDDEN_ONLINE` in manifest).
- Safe to enable/disable mid-session from the app bar.

---

## Changelog

### v1.1.0
- Fixed: contact detection now uses `car.collisionDepth` in all code paths — the previous modular version had regressed to an unreliable velocity-delta method
- Fixed: calibration trigger now uses **median** lap count (not minimum), so retired/pitted cars cannot block calibration
- Fixed: `applyPersonality()` (aggression + caution) was missing from dynamic updates
- Fixed: UI header was showing `v0.2.0`
- Added: launch boost countdown in the UI
- Added: lap-count table visible during the observation phase
- Added: aggression and caution columns in the active-phase table
- Code: unified the duplicate monolithic/modular code paths into a single clean architecture

### v1.0.0
- Initial release

---

## License

MIT — free to use, modify and redistribute with attribution.


## Safe Racing tuning

This version keeps the original adaptive AI concept but is tuned to reduce avoidable
race-ending contacts:

- Lower launch aggression and higher launch caution.
- Lower random pace variation.
- Much gentler close-battle level reduction, avoiding unnatural braking when cars are close.
- After a collision, the AI becomes temporarily more cautious and slightly less aggressive
  instead of becoming more aggressive.
- A short post-contact safety window also reduces AI level slightly.


## v1.2 Safe Racing / Global Caution

- Slightly more aggressive than the previous Safe Racing build.
- Global caution activates when a collision occurs anywhere or a car is stopped on track outside the pits.
- During caution, AI cars slow down and the player receives a throttle cut plus gentle braking.
- Caution automatically clears after the configured safety window.


### v1.3 player caution
During a global caution, the player is actively slowed toward a 30 mph (48.28 km/h) target. Above the target, throttle is cut and progressive braking is applied; near the target, throttle is capped. This is independent of AC penalty settings and runs every frame, including during the initial observation phase.
